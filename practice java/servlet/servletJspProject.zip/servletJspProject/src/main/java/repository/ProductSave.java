package repository;
import Controler.ControlClass;
import  model.Prodect;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/save")
public class ProductSave extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/plain");
        ObjectMapper mapper=new ObjectMapper();

        Prodect prodect=mapper.readValue(req.getReader(),Prodect.class);

        int id =prodect.getId();
        String name=prodect.getName();
        int price=prodect.getPrice();
        int quantity=prodect.getQuantity();

        ControlClass.addProduct(id,name,price,quantity);
        resp.getWriter().println("add product");

    }
}
